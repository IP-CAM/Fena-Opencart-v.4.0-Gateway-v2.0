<?php
/**
 * Response File Doc Comment
 * php version 7.2.10
 *
 * @category Class
 * @package  Fena
 * @author   A N Other <support@fena.co>
 * @license  https://www.fena.co General Public License
 * @link     https://www.fena.co/
 */

namespace Opencart\Catalog\Controller\Checkout;

/**
 * Response Class Doc Comment
 *
 * @category Class
 * @package  Fena
 * @author   A N Other <support@fena.co>
 * @license  https://www.fena.co General Public License
 * @link     https://www.fena.co/
 */
class Response extends \Opencart\System\Engine\Controller
{


    /**
     * Index the build template
     *
     * @return void
     */
    public function index(): void
    {
        $this->load->model('checkout/order');

        // Get Response Data from Url.
        $url = $_SERVER["REQUEST_URI"];
        $queryString = parse_url($url, PHP_URL_QUERY);
        parse_str($queryString, $queryParams);
        $resPonse = $queryParams;
        $reserveOrderId = $resPonse['order_id'];

        $status = $resPonse['status'];

        // Order Status Update.
        $this->load->model('checkout/order');
        $query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_history WHERE order_id = '" . (int) $reserveOrderId . "'");
        if ($query->num_rows) {
            foreach ($query->rows as $history) {
                // Check if the 'comment' field is not empty
                if (!empty($history['comment'])) {
                    // Decode the JSON string in the 'comment' field
                    $commentData = json_decode($history['comment'], true);

                    // Check if decoding was successful and if 'paymentId' is set
                    if ($commentData && isset($commentData['paymentId'])) {
                        $paymentId = $commentData['paymentId'];
                    }
                }
            }
        }
        $url = 'https://business.api.fena.co/payment-flow/public/payment/' . $paymentId;

        $fenaApi = html_entity_decode($this->config->get('payment_fena_api'), ENT_QUOTES, 'UTF-8');
        $fenaSecret = html_entity_decode($this->config->get('payment_fena_secret'), ENT_QUOTES, 'UTF-8');

        // Initialize cURL session
        $ch = curl_init();
        $curlArray = array(
            'integration-id: ' . $fenaApi . '',
            'secret-key: ' . $fenaSecret . '',
            'Content-Type: application/json',
        );


        // Set cURL options
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $curlArray);
        curl_setopt($ch, CURLOPT_HTTPGET, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        // Execute cURL and get the response
        $response = curl_exec($ch);
        // Close cURL session
        curl_close($ch);

        $array = json_decode($response, true);
        if ($status == $array['data']['status']) {
            $status = $array['data']['status'];
        }

        $transactionTopass = $array['data']['transaction'];

        if ($status == "paid" && $status != "rejected") {
            $reserveOrderId = $resPonse['order_id'];
            $statusId = $this->config->get('payment_fena_paid_status_id');

            $checkOrder = "SELECT * FROM  `" . DB_PREFIX . "order_history` WHERE `order_id` = '" . (int) $reserveOrderId . "' AND `order_status_id` = '" . (int) $statusId . "'";
            $query = $this->db->query($checkOrder);

            if (empty($query->rows)) {
                $this->model_checkout_order->addHistory($reserveOrderId, $statusId, $transactionTopass);
            }
            $this->response->redirect($this->url->link('checkout/success', '', true));
        }
        if ($status == "rejected") {
            $reserveOrderId = $resPonse['?order_id'];
            $statusId = $this->config->get('payment_fena_rejected_status_id');

            $checkOrder = "SELECT * FROM  `" . DB_PREFIX . "order_history` WHERE `order_id` = '" . (int) $reserveOrderId . "' AND `order_status_id` = '" . (int) $statusId . "'";
            $query = $this->db->query($checkOrder);

            if (empty($query->rows)) {
                $this->model_checkout_order->addHistory($reserveOrderId, $statusId);
            }
            $this->response->redirect($this->url->link('checkout/failure', '', true));
        }
        if ($status == "refunded") {
            $statusId = $this->config->get('payment_fena_refunded_status_id');

            $checkOrder = "SELECT * FROM  `" . DB_PREFIX . "order_history` WHERE `order_id` = '" . (int) $reserveOrderId . "' AND `order_status_id` = '" . (int) $statusId . "'";
            $query = $this->db->query($checkOrder);

            if (empty($query->rows)) {
                $this->model_checkout_order->addHistory($reserveOrderId, $statusId);
            }
            $this->response->redirect($this->url->link('checkout/success', '', true));
        }

    } //end index()


} //end class
